# Определение токсичности комментариев

Воспроизводимый учебный проект по бинарной классификации англоязычных комментариев
из Civil Comments. Итоговый протокол использует независимый test split, выбирает
гиперпараметры и порог только на validation и сохраняет все артефакты эксперимента.

## Постановка задачи

Для текста комментария требуется предсказать метку:

- `0` — нетоксичный комментарий;
- `1` — токсичный комментарий.

Используется `mteb/toxic_conversations_50k`: 50 000 train- и 50 000 test-примеров.
Метки получены из Jigsaw Unintended Bias in Toxicity Classification; исходная
непрерывная оценка токсичности бинаризована порогом `target >= 0.5`. Положительный
класс составляет около 8%, поэтому основная метрика — F1 токсичного класса, а
дополнительные — macro-F1, PR-AUC, ROC-AUC, precision, recall и accuracy.

## Эксперимент

Сравниваются три подхода:

1. `DummyClassifier(strategy="prior")`;
2. word TF-IDF + Logistic Regression;
3. word+character TF-IDF + калиброванный Linear SVM.

Исходный train очищается от пустых строк, дубликатов и пересечений с test, после
чего делится на train/validation стратифицированно в пропорции 80/20. Модель и
порог выбираются по F1 токсичного класса на validation. Test используется только
для финальной оценки выбранной конфигурации.

## Быстрый запуск

Требуется Python 3.10–3.12.

```bash
python -m pip install -r requirements-dev.txt
python scripts/run_classical.py --sample-size 2000 --max-features 5000 \
  --artifacts-dir artifacts-smoke
```

Полный эксперимент:

```bash
python scripts/run_classical.py
```

Данные автоматически загружаются с Hugging Face и кэшируются в `data/`.

## Артефакты

После запуска в `artifacts/` создаются:

- `metrics.csv` — метрики всех моделей на validation и test;
- `dataset_summary.json` — размеры и баланс классов;
- `model_metadata.json` — выбранная модель, порог и seed;
- `toxic_classifier.joblib` — модель для инференса;
- `test_predictions.parquet` — test-предсказания;
- `confusion_matrix.png` и `precision_recall_curves.png` — графики.

После полного эксперимента дополнительный анализ запускается командой:

```bash
python scripts/analyze_predictions.py
```

Он создаёт `bootstrap_ci.csv`, `threshold_comparison.csv`,
`error_analysis.csv` и `error_analysis_summary.json`. В отчёте эти артефакты
используются для доверительных интервалов, сравнения порогов и анализа ошибок.

Модель и предсказания не добавляются в Git из-за размера, но воспроизводятся одной
командой.

## Приложение

После полного обучения:

```bash
streamlit run streamlit_app.py
```

Streamlit загружает ровно ту модель и тот порог, которые были выбраны
экспериментом.

## Отчёт и ноутбуки

- `report/final_report.pdf` — расширенный готовый отчёт с численным Related Work,
  bootstrap-интервалами, сравнением порогов и анализом ошибок;
- `report/main.tex` и `report/lit.bib` — исходники в структуре шаблона курса;
- `report/report.md` — исходник локальной сборки PDF без LaTeX;
- `notebooks/toxic_comments_classification.ipynb` — чистый учебный ноутбук;
- `notebooks/original_experiment.ipynb` — исходный прототип, сохранённый для истории.

Пересобрать PDF после нового эксперимента:

```bash
python scripts/build_report.py
```

## Проверки

```bash
python -m pytest
python -m ruff check .
python -m ruff format --check .
```

Или через Make:

```bash
make test
make lint
make smoke
make report
```

## Чек-лист сдачи

1. Загрузить содержимое проекта в публичный или доступный преподавателю GitHub-репозиторий.
2. При необходимости открыть `report/main.tex` в Overleaf и проверить персональные данные.
3. Приложить `report/final_report.pdf`.
4. В поле «Решение» вставить две ссылки: на PDF и на GitHub-репозиторий.

Отчёт повторяет обязательную структуру шаблона курса: Abstract, Introduction,
Team, Related Work, Dataset, Proposed Approach, Experimental Protocol, Results,
Discussion and Limitations, Conclusion и References.

## Структура

```text
src/toxic_comments/       загрузка данных, метрики и эксперимент
scripts/                  CLI обучения и сборка PDF
tests/                    unit-тесты
notebooks/                учебный и исходный ноутбуки
report/                   текст и PDF отчёта
streamlit_app.py          демонстрационное приложение
```

## Ограничения

Проект не заявляет state of the art: опубликованные работы используют другие
подвыборки, многометочную постановку или специальные fairness-метрики, поэтому их
числа нельзя напрямую сравнивать с данным протоколом. Модель обучена на
англоязычных комментариях 2015–2017 годов и может ошибочно связывать упоминания
идентичностей с токсичностью. Для реального применения необходимы анализ
подгрупп, мониторинг сдвига данных и ручная проверка спорных решений.

## Источники данных

- https://huggingface.co/datasets/mteb/toxic_conversations_50k
- https://www.kaggle.com/competitions/jigsaw-unintended-bias-in-toxicity-classification
