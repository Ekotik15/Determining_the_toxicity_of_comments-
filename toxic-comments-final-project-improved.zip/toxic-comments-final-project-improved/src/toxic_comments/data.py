from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

TRAIN_URL = (
    "https://huggingface.co/datasets/mteb/toxic_conversations_50k/"
    "resolve/refs%2Fconvert%2Fparquet/default/train/0000.parquet"
)
TEST_URL = (
    "https://huggingface.co/datasets/mteb/toxic_conversations_50k/"
    "resolve/refs%2Fconvert%2Fparquet/default/test/0000.parquet"
)


@dataclass(frozen=True)
class DatasetSplits:
    train: pd.DataFrame
    validation: pd.DataFrame
    test: pd.DataFrame


def _read_split(url: str, cache_path: Path) -> pd.DataFrame:
    if cache_path.exists():
        frame = pd.read_parquet(cache_path)
    else:
        frame = pd.read_parquet(url)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        frame.to_parquet(cache_path, index=False)

    required_columns = {"text", "label"}
    if not required_columns.issubset(frame.columns):
        raise ValueError(f"Dataset must contain columns: {sorted(required_columns)}")

    frame = frame[["text", "label"]].dropna().copy()
    frame["text"] = frame["text"].astype(str).str.strip()
    frame["label"] = frame["label"].astype(int)
    frame = frame[frame["text"].str.len() > 0]
    if set(frame["label"].unique()) - {0, 1}:
        raise ValueError("Labels must be binary values 0 and 1")
    return frame.drop_duplicates(subset="text").reset_index(drop=True)


def _stratified_sample(
    frame: pd.DataFrame,
    sample_size: int | None,
    random_state: int,
) -> pd.DataFrame:
    if sample_size is None or sample_size >= len(frame):
        return frame
    sampled, _ = train_test_split(
        frame,
        train_size=sample_size,
        random_state=random_state,
        stratify=frame["label"],
    )
    return sampled.reset_index(drop=True)


def load_splits(
    cache_dir: Path,
    validation_size: float = 0.2,
    random_state: int = 42,
    sample_size: int | None = None,
) -> DatasetSplits:
    if not 0 < validation_size < 1:
        raise ValueError("validation_size must be between 0 and 1")
    if sample_size is not None and sample_size < 100:
        raise ValueError("sample_size must be at least 100")

    source_train = _read_split(TRAIN_URL, cache_dir / "train.parquet")
    source_test = _read_split(TEST_URL, cache_dir / "test.parquet")

    test_texts = set(source_test["text"])
    source_train = source_train[~source_train["text"].isin(test_texts)].reset_index(drop=True)

    source_train = _stratified_sample(source_train, sample_size, random_state)
    source_test = _stratified_sample(source_test, sample_size, random_state + 1)

    train, validation = train_test_split(
        source_train,
        test_size=validation_size,
        random_state=random_state,
        stratify=source_train["label"],
    )
    return DatasetSplits(
        train=train.reset_index(drop=True),
        validation=validation.reset_index(drop=True),
        test=source_test.reset_index(drop=True),
    )
