from pathlib import Path

import pandas as pd
import pytest

from toxic_comments import data


def test_load_splits_removes_overlap_and_preserves_labels(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    train = pd.DataFrame(
        {
            "text": [f"train {index}" for index in range(100)] + ["shared"],
            "label": [index % 2 for index in range(100)] + [1],
        }
    )
    test = pd.DataFrame(
        {
            "text": [f"test {index}" for index in range(100)] + ["shared"],
            "label": [index % 2 for index in range(100)] + [0],
        }
    )

    def fake_read_split(url: str, cache_path: Path) -> pd.DataFrame:
        del cache_path
        return train.copy() if url == data.TRAIN_URL else test.copy()

    monkeypatch.setattr(data, "_read_split", fake_read_split)
    splits = data.load_splits(tmp_path, validation_size=0.2)

    assert "shared" not in set(splits.train["text"])
    assert "shared" not in set(splits.validation["text"])
    assert set(splits.train["label"]) == {0, 1}
    assert set(splits.validation["label"]) == {0, 1}
    assert set(splits.test["label"]) == {0, 1}


def test_load_splits_rejects_tiny_sample(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="at least 100"):
        data.load_splits(tmp_path, sample_size=50)
